using LoginAndRegister.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Register services
builder.Services.AddScoped<SecurityDAO>();
builder.Services.AddScoped<SecurityService>();
builder.Services.AddScoped<MinesweeperDAO>();
builder.Services.AddScoped(provider =>
{
    var userId = "user123"; // Replace with your logic to get the user ID
    var dao = provider.GetRequiredService<MinesweeperDAO>();
    return new MinesweeperService(dao, userId);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
