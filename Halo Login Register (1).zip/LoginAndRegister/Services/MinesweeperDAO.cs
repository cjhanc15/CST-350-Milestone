﻿using System.Collections.Generic;
using LoginAndRegister.Models;

public class MinesweeperDAO
{
    private readonly Dictionary<string, GameModel> _games = new Dictionary<string, GameModel>();

    public void SaveGame(GameModel game)
    {
        _games[game.Id] = game;
    }

    public GameModel? LoadGame(string userId, string gameId)
    {
        if (_games.TryGetValue(gameId, out var game) && game.User.Id == userId)
        {
            return game;
        }
        return null;
    }
}
