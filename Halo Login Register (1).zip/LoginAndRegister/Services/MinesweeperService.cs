﻿using LoginAndRegister.Models;

public class MinesweeperService
{
    private readonly MinesweeperDAO _dao;
    private readonly string _userId;

    public MinesweeperService(MinesweeperDAO dao, string userId)
    {
        _dao = dao;
        _userId = userId;
    }

    public GameModel? CurrentGame(string gameId)
    {
        return _dao.LoadGame(_userId, gameId);
    }

    public string StartNewGame(int rows = 10, int cols = 10, int mines = 20)
    {
        var newGame = new GameModel(new UserModel { Id = _userId });
        newGame.NewGame(); // Call NewGame to initialize the board
        _dao.SaveGame(newGame);
        return newGame.Id;
    }

    public CellModel? ClickCell(string gameId, int row, int col)
    {
        var game = _dao.LoadGame(_userId, gameId);

        if (game == null || game.Status.Status != "In Progress" || !game.Board.IsValidCell(row, col))
            return null;

        game.MakeMove(row, col);
        _dao.SaveGame(game);
        return game.Board.Cells[row, col];
    }

    public CellModel? FlagCell(string gameId, int row, int col)
    {
        var game = _dao.LoadGame(_userId, gameId);

        if (game == null || game.Status.Status != "In Progress" || !game.Board.IsValidCell(row, col))
            return null;

        var cell = game.Board.Cells[row, col];
        cell.ToggleFlag();
        _dao.SaveGame(game);
        return cell;
    }
}
