﻿using LoginAndRegister.Models;

namespace LoginAndRegister.Services
{
    public class SecurityService
    {
        private readonly SecurityDAO _securityDAO;

        public SecurityService(SecurityDAO securityDAO)
        {
            _securityDAO = securityDAO;
        }

        public bool IsValid(UserModel user)
        {
            return _securityDAO.FindUserByNameAndPassword(user);
        }

        public bool RegisterUser(UserModel user)
        {
            // Implement the logic to register the user
            // Return true if registration is successful, otherwise false
            return _securityDAO.RegisterUser(user);
        }
    }
}
