using LoginAndRegister.Models;
using Microsoft.AspNetCore.Mvc;

public class MinesweeperController : Controller
{
    private static GameModel? CurrentGame;

    public MinesweeperController()
    {
        if (CurrentGame == null)
        {
            // Example: Initialize with a default user. Replace with actual logged-in user.
            CurrentGame = new GameModel(new UserModel { Id = "1", FirstName = "John", LastName = "Doe", Email = "john.doe@example.com" });
        }
    }

    public IActionResult Index()
    {
        if (CurrentGame == null)
        {
            return RedirectToAction("Error"); // Or any other appropriate action
        }

        return View(CurrentGame);
    }

    [HttpGet]
    public JsonResult ClickCell(int row, int col)
    {
        if (CurrentGame == null)
        {
            return Json(new { error = "Game not initialized" });
        }

        CurrentGame.Board.RevealCell(row, col);
        var cell = CurrentGame.Board.Cells[row, col];

        var revealedCells = new List<object>();
        for (int r = 0; r < CurrentGame.Board.Rows; r++)
        {
            for (int c = 0; c < CurrentGame.Board.Columns; c++)
            {
                var currentCell = CurrentGame.Board.Cells[r, c];
                if (currentCell.IsRevealed)
                {
                    revealedCells.Add(new
                    {
                        row = r,
                        col = c,
                        isMine = currentCell.IsMine,
                        adjacentMines = currentCell.AdjacentMines
                    });
                }
            }
        }

        return Json(new
        {
            isMine = cell.IsMine,
            revealedCells
        });
    }

    [HttpGet]
    public JsonResult FlagCell(int row, int col)
    {
        if (CurrentGame == null)
        {
            return Json(new { error = "Game not initialized" });
        }

        var cell = CurrentGame.Board.Cells[row, col];
        cell.ToggleFlag();

        return Json(new
        {
            isFlagged = cell.IsFlagged,
            row = row,
            col = col
        });
    }
}
