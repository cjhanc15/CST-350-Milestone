﻿using LoginAndRegister.Models;
using LoginAndRegister.Services;
using Microsoft.AspNetCore.Mvc;

namespace LoginAndRegister.Controllers
{
    public class LoginController : Controller
    {
        private readonly SecurityService _securityService;

        public LoginController(SecurityService securityService)
        {
            _securityService = securityService;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(UserModel user)
        {
            if (_securityService.IsValid(user))
            {
                // Pass the user data to LoginSuccess to initialize the game model
                return RedirectToAction("LoginSuccess", new { username = user.Username });
            }
            else
            {
                return RedirectToAction("LoginFailure", new { username = user.Username });
            }
        }

        public IActionResult LoginSuccess(string username)
        {
            // Create a GameModel instance
            var gameModel = new GameModel
            {
                Board = new BoardModel(10, 10, 10)

            };

            ViewBag.Username = username; // Pass the username using ViewBag

            return View(gameModel);
        }

        public IActionResult LoginFailure(string username)
        {
            ViewBag.Username = username; // Pass the username using ViewBag
            return View();
        }
    }
}
