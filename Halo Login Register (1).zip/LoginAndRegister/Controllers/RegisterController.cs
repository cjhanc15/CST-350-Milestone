﻿using LoginAndRegister.Models;
using LoginAndRegister.Services;
using Microsoft.AspNetCore.Mvc;

namespace LoginAndRegister.Controllers
{
    public class RegisterController : Controller
    {
        private readonly SecurityService _securityService;

        public RegisterController(SecurityService securityService)
        {
            _securityService = securityService;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(UserModel user)
        {
            if (ModelState.IsValid)
            {
                bool registrationSuccess = _securityService.RegisterUser(user);
                if (registrationSuccess)
                {
                    return RedirectToAction("Index", "Login"); // Redirect to the Login page after successful registration
                }
                else
                {
                    ModelState.AddModelError("", "Registration failed. Please try again.");
                }
            }

            return View(); // Show the same view with validation errors
        }
    }
}
