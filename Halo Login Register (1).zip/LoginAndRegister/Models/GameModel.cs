using LoginAndRegister.Models;

public class GameModel
{
    public string Id { get; set; }
    public UserModel User { get; set; }
    public GameStatusModel Status { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public BoardModel Board { get; set; }

    // Default constructor
    public GameModel()
    {
        Id = Guid.NewGuid().ToString();
        User = new UserModel();
        Status = new GameStatusModel { Status = "Not Started" };
        StartTime = DateTime.MinValue;
        EndTime = DateTime.MinValue;
        Board = new BoardModel(10, 10, 20);
    }

    // Constructor with User parameter
    public GameModel(UserModel user)
    {
        Id = Guid.NewGuid().ToString();
        User = user;
        Status = new GameStatusModel { Status = "In Progress" };
        StartTime = DateTime.Now;
        Board = new BoardModel(10, 10, 20);
    }

    public void NewGame()
    {
        Board = new BoardModel(10, 10, 20);
        StartTime = DateTime.Now;
        Status.Status = "In Progress";
    }

    public void MakeMove(int row, int col)
    {
        if (Board.Cells[row, col].IsMine)
        {
            Status.Status = "Game Over";
            EndTime = DateTime.Now;
        }
        else
        {
            Board.RevealCell(row, col);
            CheckStatus();
        }
    }



    public void CheckStatus()
    {
        // Implement logic to check if the game is won or still in progress
    }
}
