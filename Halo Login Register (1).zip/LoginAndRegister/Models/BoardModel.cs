public class BoardModel
{
    public CellModel[,] Cells { get; set; }
    public int Rows { get; set; }
    public int Columns { get; set; }
    public int Mines { get; set; }

    private static readonly Random Random = new Random();

    public BoardModel(int rows, int columns, int mines)
    {
        Rows = rows;
        Columns = columns;
        Mines = mines;
        Cells = new CellModel[rows, columns];
        Initialize();
    }

    private void Initialize()
    {
        for (int row = 0; row < Rows; row++)
        {
            for (int col = 0; col < Columns; col++)
            {
                Cells[row, col] = new CellModel();
            }
        }
        PlaceMines();
        CalculateAdjacentMines();
    }

    private void PlaceMines()
    {
        for (int i = 0; i < Mines; i++)
        {
            int row, col;
            do
            {
                row = Random.Next(Rows);
                col = Random.Next(Columns);
            } while (Cells[row, col].IsMine);

            Cells[row, col].IsMine = true;
        }
    }

    private void CalculateAdjacentMines()
    {
        for (int row = 0; row < Rows; row++)
        {
            for (int col = 0; col < Columns; col++)
            {
                if (!Cells[row, col].IsMine)
                {
                    Cells[row, col].AdjacentMines = CountAdjacentMines(row, col);
                }
            }
        }
    }

    private int CountAdjacentMines(int row, int col)
    {
        int count = 0;
        for (int i = -1; i <= 1; i++)
        {
            for (int j = -1; j <= 1; j++)
            {
                int newRow = row + i;
                int newCol = col + j;
                if (IsValidCell(newRow, newCol) && Cells[newRow, newCol].IsMine)
                {
                    count++;
                }
            }
        }
        return count;
    }

    public void RevealCell(int row, int col)
    {
        if (!IsValidCell(row, col) || Cells[row, col].IsRevealed || Cells[row, col].IsFlagged)
        {
            return;
        }

        Cells[row, col].Reveal();

        if (Cells[row, col].AdjacentMines == 0)
        {
            FloodFill(row, col);
        }
    }

    private void FloodFill(int row, int col)
    {
        Stack<(int, int)> stack = new Stack<(int, int)>();
        stack.Push((row, col));

        while (stack.Count > 0)
        {
            var (currentRow, currentCol) = stack.Pop();
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    int newRow = currentRow + i;
                    int newCol = currentCol + j;
                    if (IsValidCell(newRow, newCol) && !Cells[newRow, newCol].IsRevealed && !Cells[newRow, newCol].IsMine && !Cells[newRow, newCol].IsFlagged)
                    {
                        Cells[newRow, newCol].Reveal();
                        if (Cells[newRow, newCol].AdjacentMines == 0)
                        {
                            stack.Push((newRow, newCol));
                        }
                    }
                }
            }
        }
    }

    public bool IsValidCell(int row, int col)
    {
        return row >= 0 && row < Rows && col >= 0 && col < Columns;
    }
}
