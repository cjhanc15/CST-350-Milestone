public class CellModel
{
    public bool IsMine { get; set; }
    public bool IsRevealed { get; set; }
    public bool IsFlagged { get; set; }
    public int AdjacentMines { get; set; }

    public void Reveal()
    {
        IsRevealed = true;
    }

    public void ToggleFlag()
    {
        IsFlagged = !IsFlagged;
    }
}
