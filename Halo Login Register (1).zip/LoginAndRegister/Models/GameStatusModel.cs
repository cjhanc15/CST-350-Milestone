public class GameStatusModel
{
    public string Status { get; set; }

    public GameStatusModel()
    {
        Status = "Not started";
    }

    public GameStatusModel(String status)
    {
        Status = status;
    }
}
