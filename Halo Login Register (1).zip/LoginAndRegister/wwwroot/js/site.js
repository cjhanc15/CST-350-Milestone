﻿document.addEventListener('DOMContentLoaded', () => {
    const cells = document.querySelectorAll('.cell');
    const timestampDiv = document.createElement('div');
    timestampDiv.id = 'timestamp';
    document.body.appendChild(timestampDiv);

    function updateTimestamp() {
        const now = new Date();
        timestampDiv.textContent = `Last Update: ${now.toLocaleTimeString()}`;
    }

    const updateCells = (revealedCells) => {
        revealedCells.forEach(cellData => {
            const targetCell = document.querySelector(`.cell[data-row="${cellData.row}"][data-col="${cellData.col}"]`);
            if (targetCell) {
                if (cellData.isMine) {
                    targetCell.classList.add('mine');
                    targetCell.innerHTML = '💣';
                } else {
                    targetCell.textContent = cellData.adjacentMines > 0 ? cellData.adjacentMines : '';
                    targetCell.classList.add('safe');
                }
                targetCell.classList.add('revealed');
            }
        });
    };

    const handleClick = (event) => {
        const cell = event.target;
        const row = cell.getAttribute('data-row');
        const col = cell.getAttribute('data-col');

        fetch(`/Minesweeper/ClickCell?row=${row}&col=${col}`)
            .then(response => response.json())
            .then(data => {
                if (data.isMine) {
                    cell.classList.add('mine');
                    cell.innerHTML = '💣';
                    alert('Game Over!');
                } else {
                    updateCells(data.revealedCells);
                }
                updateTimestamp();
            })
            .catch(error => {
                console.error('Error:', error);
                updateTimestamp();
            });
    };

    const handleContextMenu = (event) => {
        event.preventDefault();

        const cell = event.target;
        const row = cell.getAttribute('data-row');
        const col = cell.getAttribute('data-col');

        fetch(`/Minesweeper/FlagCell?row=${row}&col=${col}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                cell.innerHTML = data.isFlagged ? "&#x1F3F3;" : "";
                cell.classList.toggle('flagged', data.isFlagged);
                updateTimestamp();
            })
            .catch(error => {
                console.error('Error:', error);
                updateTimestamp();
            });
    };

    cells.forEach(cell => {
        cell.addEventListener('click', handleClick);
        cell.addEventListener('contextmenu', handleContextMenu);
    });

    updateTimestamp(); // Initial timestamp
});
